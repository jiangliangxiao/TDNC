package ceka.TDNC.code;

import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Worker;
import weka.classifiers.Classifier;
import weka.classifiers.lazy.IBk;
import weka.classifiers.trees.J48;

public class tdnc {
    // 纠正后的噪声集
    public Dataset cleanDatasets;

    // 初始化数据集
    private Dataset initDataset(Dataset dataset) {
        Dataset subData = dataset.generateEmpty();
        //数据集大小
        int numCateSize = dataset.getCategorySize();
        for(int c = 0; c < numCateSize; c++) {
            Category cate = dataset.getCategory(c);
            subData.addCategory(cate.copy());
        }
        return subData;
    }

    // 数据集复制
    public  Dataset Datasetcopy(Dataset dataset) {

        Dataset newDataset = dataset.generateEmpty();
        int numCateSize = dataset.getCategorySize();
        for (int i = 0; i < numCateSize; i++) {
            Category cate = dataset.getCategory(i);
            newDataset.addCategory(cate.copy());
        }

        for (int j = 0; j < dataset.getExampleSize(); j++) {
            Example example = dataset.getExampleByIndex(j);
            // Error, isn't change the rate
            newDataset.addExample(example);
            for (int k = 0; k < example.getWorkerIdList().size(); k++) {
                String wID = example.getWorkerIdList().get(k);
                Worker worker = newDataset.getWorkerById(wID);
                if (worker == null)
                    newDataset.addWorker(worker = new Worker(wID));
            }
        }
        return newDataset;
    }

    // 噪声过滤
    public Dataset filterNoise(Dataset data) throws Exception{
        // tempData临时数据集
        Dataset tempData = Datasetcopy(data);
        // cleanDatasets是最终获取的干净数据集（噪声纠正后的数据集）
        cleanDatasets = initDataset(tempData);
        // 初始化
        Dataset cleanData = initDataset(tempData);
        Dataset noiseData = initDataset(tempData);
        Dataset unsureData = initDataset(tempData);
        //构造分类器
        Classifier[] classifiers = new Classifier[3];
        classifiers[0] = new IBk(1);  //找最近邻
        classifiers[1] = new IBk(1);
        classifiers[2] = new J48();
        //第一阶段：划分数据集
        for(int j = 0; j < tempData.getExampleSize(); j++) {
            Example e = tempData.getExampleByIndex(j);
            double[] count = new double[tempData.getCategorySize()];
            //集成标
            double label = e.getIntegratedLabel().getValue();
            //多噪声标记集合大小
            double L = e.getMultipleNoisyLabelSet(0).getLabelSetSize();
            //种类数
            double N = 0;
            for(int i = 0; i < L; i++)
            {
                count[e.getMultipleNoisyLabelSet(0).getLabel(i).getValue()]++;
            }
            for(int i = 0; i < tempData.getCategorySize(); i++)
            {
                if(count[i] != 0) {
                    N++;
                }
            }
            //标签确定度
            double LC = count[(int)label] / L;
            //紧致性
            double C = (1.0 / N) * (1.0 / L);
            // 划分数据集
            if(LC > 0.5 + C) {
                cleanData.addExample(e);
            } else if (LC < 0.5 - C){
                noiseData.addExample(e);
            }else {
                unsureData.addExample(e);
            }
        }
        //第二阶段再过滤
        classifiers[0].buildClassifier(cleanData);
        //遍历不确定数据集中的每一个实例
        for (int i = 0; i < unsureData.getExampleSize(); i++) {
            Example example = unsureData.getExampleByIndex(i);
            // 实例集成标
            double label1 = example.getIntegratedLabel().getValue();
            // 实例预测标
            double label2 = classifiers[0].classifyInstance(example);
            if (label1 == label2) {
                cleanData.addExample(example);
            } else {
                noiseData.addExample(example);
            }
        }
        //第三阶段进行噪声纠正
        classifiers[1].buildClassifier(cleanData);
        classifiers[2].buildClassifier(cleanData);
        for (int i = 0; i < noiseData.getExampleSize(); i++) {
            //第i个实例
            Example example = noiseData.getExampleByIndex(i);
            int[] preLabel = new int[2];
            for (int j = 1; j < 3; j++) {
                preLabel[j - 1] = (int) classifiers[j].classifyInstance(example);
            }
            if (preLabel[0] == preLabel[1] && preLabel[0] != example.getIntegratedLabel().getValue()) {
                example.getIntegratedLabel().setValue(preLabel[0]);
                example.setTrainingLabel(preLabel[0]);
                cleanData.addExample(example);
            } else {
                cleanData.addExample(example);
            }
        }
        cleanDatasets = Datasetcopy(cleanData);
        return cleanDatasets;
    }
}
