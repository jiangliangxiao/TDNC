package ceka.TDNC.code;

import ceka.simulation.MockWorker;
import ceka.simulation.SingleQualLabelingStrategy;

import java.util.Random;

public class LabelStrategy extends SingleQualLabelingStrategy {
//public class LabelStrategy extends mySingleQualLabelingStrategy {

	public LabelStrategy(double p) {
		super(p);
		// TODO Auto-generated constructor stub
	}
	
	public void RandomAssignWorkerQuality(MockWorker[] workers,double baseline, double var) {
		for (int i = 0; i < workers.length; i++) {
			double pro = 0;
			Random random = new Random();
			pro = random.nextDouble() * var + baseline;
			workers[i].setSingleQuality(pro);
		}
//		for (int i = 0; i < workers.length; i++) {
//			double pro = 0;
//			Random random = new Random();
//			if (i < 4) {
//				pro = random.nextDouble() * 0.4 + 0.1;
//				workers[i].setSingleQuality(pro);   //低质量
////			}else if(i == workers.length-1){
////				pro = random.nextDouble()*0.7 + 0.2;
////				workers[i].setSingleQuality(pro);    //随机
//			}else {
//				pro = random.nextDouble()*0.4 + 0.5;
//				workers[i].setSingleQuality(pro);    //高质量
//			}
//		}
	}

}
