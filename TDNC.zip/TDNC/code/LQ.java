package ceka.TDNC.code;

import ceka.consensus.MajorityVote;
import ceka.converters.FileLoader;
import ceka.converters.FileSaver;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Worker;
import ceka.noise.ClassificationFilter;
import ceka.noise.PolishingLabels;
import ceka.noise.SelfTrainCorrection;
import ceka.noise.avnc.AdaptiveClassificationFilter;
import ceka.noise.avnc.VoteCorrection;
import ceka.noise.avnc.WorkerStat;
import ceka.noise.clustering.ClusterCorrection;
import ceka.others.CTNC.CENC;
import ceka.others.CTNC.CTNC;
import ceka.others.DVNC.DVNC;
import ceka.others.IDNC.IDNC;
import ceka.others.LDNC.LDNC;
import ceka.simulation.MockWorker;
import ceka.utils.DatasetManipulator;
import ceka.utils.Stochastics;
import weka.clusterers.Clusterer;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.clusterers.SimpleKMeans;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;


public class LQ {
    private static Dataset m_dataset=null;

    // 大数据集34个 "letter",
    private static String[] dataname= {"anneal", "audiology","autos","balance-scale","biodeg",
            "breast-cancer","breast-w","car","credit-a","credit-g","diabetes","heart-c","heart-h","heart-statlog",
            "hepatitis","horse-colic","hypothyroid","ionosphere","iris","kr-vs-kp","labor","letter","lymph","mushroom",
            "segment","sick","sonar","spambase","tic-tac-toe","vehicle","vote","vowel","waveform","zoo"};

    public void readData(int m_choose, double quality, int numWorker) throws Exception {
        String arffPath = "TDNC/data/simulation/" + dataname[m_choose] + ".arff";
        m_dataset = FileLoader.loadFile(arffPath);
        simulateDataset(m_dataset, quality, numWorker);
    }

    public static Dataset Datasetcopy(Dataset dataset) {
        Dataset newdataset = dataset.generateEmpty();
        int numCateSize = dataset.getCategorySize();
        for (int i = 0; i < numCateSize; i++) {
            Category cate = dataset.getCategory(i);
            newdataset.addCategory(cate.copy());
        }

        for (int j = 0; j < dataset.getExampleSize(); j++) {
            Example example = dataset.getExampleByIndex(j);
            // Error, isn't change the rate
            newdataset.addExample(example);
            for (int k = 0; k < example.getWorkerIdList().size(); k++) {
                String wID = example.getWorkerIdList().get(k);
                Worker worker = newdataset.getWorkerById(wID);
                if (worker == null)
                    newdataset.addWorker(worker = new Worker(wID));
            }
        }
        return newdataset;
    }

    public void Integration(Dataset dataset) throws Exception {
        MajorityVote mv = new MajorityVote();
        mv.doInference(dataset);
//        RLAWMV rlawmv = new RLAWMV();
//        rlawmv.doInference(dataset,5);
    }

    public double EvaluateFiltedExamples(Dataset trainDataset, Dataset testDataset) throws Exception {

        J48 classifier = new J48();
        classifier.buildClassifier(trainDataset);
        weka.classifiers.Evaluation eval = new weka.classifiers.Evaluation(trainDataset);
        eval.evaluateModel(classifier, testDataset);
        return eval.pctCorrect();

    }

    public double NoisyRatio(Dataset dataset) {

        int numNoisyExample = 0;
        for (int i = 0; i < dataset.getExampleSize(); i++) {
            Example example = dataset.getExampleByIndex(i);
            if (example.getIntegratedLabel().getValue() != example
                    .getTrueLabel().getValue())
                numNoisyExample++;
        }
        return 100 * numNoisyExample / (double) dataset.getExampleSize();
    }

    public static void simulateDataset(Dataset dataset, double quality, int numWorkers) {
        MockWorker[] mockWorkers = new MockWorker[numWorkers];
        for (int id = 0; id < numWorkers; id++) {
            mockWorkers[id] = new MockWorker(String.valueOf(id));
        }
        //均匀分布
        LabelStrategy strategy = new LabelStrategy(quality);
        strategy.RandomAssignWorkerQuality(mockWorkers, 0.3, 0.6);
        //strategy.assignWorkerQuality(mockWorkers);
        //高斯分布
//        GaussianLabelingStrategy strategy = new GaussianLabelingStrategy(0.65,0.05);
//        strategy.assignWorkerQuality(mockWorkers);
        for (int j = 0; j < numWorkers; j++) {
            mockWorkers[j].labeling(dataset, strategy);
        }
    }

    public static void main(String[] args) {

        double meanNoiseMV = 0;
        double meanNoisePL = 0;
        double meanNoiseSTC = 0;
        double meanNoiseCC = 0;
        double meanNoiseAVNC = 0.0;
        double meanNoiseCENC = 0.0;
        double meanNoiseCTNC = 0.0;
        double meanNoiseLDNC = 0;
        double meanNoiseIDNC = 0;
        double meanNoiseDVNC = 0;
        double meanNoiseTDNC = 0;

        //设置工人参数
        double quality = 0.55;   //0.55-0.75
        int numWorker = 7;

        try {
            String resultPath1 = "TDNC/result/res_s_" + quality + "_" + numWorker + ".txt";
            FileOutputStream fs1 = new FileOutputStream(new File(resultPath1));
            PrintStream result1 = new PrintStream(fs1);
            result1.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s",
                    "Dataset", "MV", "PL", "STC", "CC", "AVNC", "CENC", "CTNC", "LDNC", "IDNC", "DVNC","TDNC");
            result1.println();

            for (int i = 0; i < dataname.length; i++) {
                double noiseMV = 0;
                double noisePL = 0;
                double noiseSTC = 0;
                double noiseCC = 0;
                double noiseAVNC = 0;
                double noiseCENC = 0;
                double noiseCTNC = 0;
                double noiseLDNC = 0;
                double noiseIDNC = 0;
                double noiseDVNC = 0;
                double noiseTDNC = 0;

                for (int m = 1 ; m <= 10; m++) {
                    LQ expriment = new LQ();
                    expriment.readData(i, quality, numWorker);

                    //得到集成标
                    expriment.Integration(m_dataset);

                    // Majority Voting
                    Dataset tempDataMV = Datasetcopy(m_dataset);
                    noiseMV += expriment.NoisyRatio(tempDataMV);
                    System.out.println("MV finished!");

                    // PL
                    Dataset tempDataPL = Datasetcopy(m_dataset);
                    Classifier classifier = new J48();
                    PolishingLabels pl = new PolishingLabels(classifier);
                    Dataset modifydata = pl.polishLabels(tempDataPL);
                    noisePL += expriment.NoisyRatio(modifydata);
                    System.out.println("PL finished!");

                    //STC
                    ClassificationFilter cfSTC = new ClassificationFilter(10);
                    Classifier [] classifiersSTC = new Classifier[1];
                    classifiersSTC[0] = new J48();
                    Dataset temp = Datasetcopy(m_dataset);
                    cfSTC.filterNoise(temp, classifiersSTC);
                    Dataset[] tempDataSTC = new Dataset[2];
                    Dataset cleanSetSTC = cfSTC.getCleansedDataset();
                    Dataset noiseSetSTC= cfSTC.getNoiseDataset();
                    Classifier classifierSTC = new J48();
                    SelfTrainCorrection stc = new SelfTrainCorrection(cleanSetSTC, noiseSetSTC, 0.8);
                    tempDataSTC = stc.correction(classifierSTC);
                    DatasetManipulator.addAllExamples(tempDataSTC[0], tempDataSTC[1]);
                    noiseSTC += expriment.NoisyRatio(tempDataSTC[0]);
                    System.out.println("STC finished!");

                    //CC
                    Dataset tempDataCC = Datasetcopy(m_dataset);
                    int numClusters = 10;
                    Clusterer[] clusterers = new Clusterer[numClusters];
                    for (int c = 0; c < numClusters; c++) {
                        int k = (int) (((double) (c + 1) / (double) (numClusters)) * (tempDataCC.getExampleSize() / 2.0));
                        if (c == 0)
                            k = k + 2;
                        SimpleKMeans simpleKMeans = new SimpleKMeans();
                        simpleKMeans.setMaxIterations(200);
                        simpleKMeans.setNumClusters(k);
                        clusterers[c] = simpleKMeans;
                    }
                    String arffPath = "TDNC/arff/" + dataname[i] + m + ".arff";
                    FileSaver.saveDatasetArff(tempDataCC, arffPath);
                    ClusterCorrection cc = new ClusterCorrection(tempDataCC, arffPath, clusterers);
                    Dataset modifyDataset = cc.correction();
                    noiseCC += expriment.NoisyRatio(modifyDataset);
                    System.out.println("CC finished!");

                    //AVNC
                    Dataset tempDataAVNC = Datasetcopy(m_dataset);
                    WorkerStat workerStat = new WorkerStat();
                    double estimatedMeanProb = workerStat.calculateEstimatedMeanAcc(m_dataset);
                    double integratedCorrectProb = Stochastics.binomialIntegration(9, estimatedMeanProb);
                    int nfold = 10;
                    int nModel = 5;
                    AdaptiveClassificationFilter acf = new AdaptiveClassificationFilter(nfold,nModel);
                    acf.setMinEstimatedNoiseProportion(1 - integratedCorrectProb);
                    acf.setMaxEstimatedNoiseProportion(1 - estimatedMeanProb);
                    Classifier[] classifiersAVNC = new Classifier[5];
                    for(int k = 0; k < 5; k++) {
                        classifiersAVNC[k] = new J48();
                    }
                    acf.filterNoise(tempDataAVNC, classifiersAVNC);
                    Dataset cleanSetAVNC = acf.getCleansedDataset();
                    Dataset noiseSetAVNC = acf.getNoiseDataset();
                    Dataset[] highDatasets=acf.getHighQualityDatasets();

                    VoteCorrection corrector = new VoteCorrection();
                    corrector.correct(noiseSetAVNC, highDatasets, classifiersAVNC, (int)(highDatasets.length * 0.5));
                    for(int k = 0; k < noiseSetAVNC.getExampleSize();k++){
                        cleanSetAVNC.addExample(noiseSetAVNC.getExampleByIndex(k));
                    }
                    noiseAVNC += expriment.NoisyRatio(cleanSetAVNC);
                    System.out.println("AVNC finished!");

                    //CENC
                    Dataset tempDataCENC = Datasetcopy(m_dataset);
                    CENC Cenc = new CENC(10,0.1);
                    Classifier classifierCENC = new J48();
                    Dataset correctedCENC = Cenc.cenc(tempDataCENC, classifierCENC);
                    noiseCENC += expriment.NoisyRatio(correctedCENC);
                    System.out.println("CENC finished!");

                    //CTNC
                    Dataset tempDataCTNC = Datasetcopy(m_dataset);
                    CTNC ctnc = new CTNC();
                    double[] weights = ctnc.calculateWeights(tempDataCTNC);
                    for(int k = 0; k < tempDataCTNC.getExampleSize();k++) {
                        tempDataCTNC.getExampleByIndex(k).setWeight(weights[k]);
                    }
                    Classifier[] classifiersCTNC = new Classifier[1];
                    classifiersCTNC[0] = new J48();
                    ClassificationFilter cfCTNC = new ClassificationFilter(10);
                    cfCTNC.filterNoise(tempDataCTNC, classifiersCTNC);
                    Dataset cleanSetCTNC = cfCTNC.getCleansedDataset();
                    Dataset noiseSetCTNC = cfCTNC.getNoiseDataset();
                    Dataset correctedCTNC = ctnc.noiseCorrection(cleanSetCTNC, noiseSetCTNC,7,0.8);
                    noiseCTNC += expriment.NoisyRatio(correctedCTNC);
                    System.out.println("CTNC finished!");

                    //LDNC
                    LDNC Ldnc = new LDNC(0.2);
                    Classifier classifierLDNC = new J48();
                    Dataset tempDataLDNC = Datasetcopy(m_dataset);
                    Dataset correctedLDNC = Ldnc.ldnc(tempDataLDNC, classifierLDNC);
                    noiseLDNC += expriment.NoisyRatio(correctedLDNC);
                    System.out.println("LDNC finished!");

                    //IDNC
                    IDNC idnc = new IDNC();
                    Dataset tempDataIDNC = Datasetcopy(m_dataset);
                    Dataset correctedIDNC = idnc.IDNC(tempDataIDNC);
                    noiseIDNC += expriment.NoisyRatio(correctedIDNC);
                    System.out.println("IDNC finished!");

                    //DVNC
                    Dataset tempDataDVNC = Datasetcopy(m_dataset);
                    DVNC dvnc = new DVNC();
                    Dataset correctedDVNC = dvnc.doInference(tempDataDVNC, 0.6);
                    noiseDVNC += expriment.NoisyRatio(correctedDVNC);
                    System.out.println("DVNC finished!");

                    //TDNC
                    tdnc tdnc = new tdnc();
                    Dataset tempDataTDNC = Datasetcopy(m_dataset);
                    Dataset correctedTDNC = tdnc.filterNoise(tempDataTDNC);
                    noiseTDNC += expriment.NoisyRatio(correctedTDNC);
                    System.out.println("TDNC finished!");
                    System.out.println("************************");
                    System.out.println(dataname[i] + "  " + m + " fold" + " finished.");
                    System.out.println("************************");
                }
                noiseMV /= 10;
                noisePL /= 10;
                noiseSTC /= 10;
                noiseCC /= 10;
                noiseAVNC /= 10;
                noiseCENC /= 10;
                noiseCTNC /= 10;
                noiseLDNC /= 10;
                noiseIDNC /= 10;
                noiseDVNC /= 10;
                noiseTDNC /= 10;

                meanNoiseMV += noiseMV;
                meanNoisePL += noisePL;
                meanNoiseSTC += noiseSTC;
                meanNoiseCC += noiseCC;
                meanNoiseAVNC += noiseAVNC;
                meanNoiseCENC += noiseCENC;
                meanNoiseCTNC += noiseCTNC;
                meanNoiseLDNC += noiseLDNC;
                meanNoiseIDNC += noiseIDNC;
                meanNoiseDVNC += noiseDVNC;
                meanNoiseTDNC += noiseTDNC;

                result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataname[i],
                        noiseMV, noisePL, noiseSTC, noiseCC, noiseAVNC, noiseCENC, noiseCTNC, noiseLDNC, noiseIDNC, noiseDVNC, noiseTDNC);
                result1.println();
            }

            meanNoiseMV /= dataname.length;
            meanNoisePL /= dataname.length;
            meanNoiseSTC /= dataname.length;
            meanNoiseCC /= dataname.length;
            meanNoiseAVNC /= dataname.length;
            meanNoiseCENC /= dataname.length;
            meanNoiseCTNC /= dataname.length;
            meanNoiseLDNC /= dataname.length;
            meanNoiseIDNC /= dataname.length;
            meanNoiseDVNC /= dataname.length;
            meanNoiseTDNC /= dataname.length;

            result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f","Mean",
                    meanNoiseMV, meanNoisePL, meanNoiseSTC, meanNoiseCC, meanNoiseAVNC, meanNoiseCENC, meanNoiseCTNC, meanNoiseLDNC,
                    meanNoiseIDNC, meanNoiseDVNC, meanNoiseTDNC);
            result1.println();
            result1.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());        }
    }
}



